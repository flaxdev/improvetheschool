function [X,Y,Z] = graphECMgravitySource(source)


     X0 = source.Parameters(1);
     Y0 = source.Parameters(2);
     depth = source.Parameters(3);
     omegaX = source.Parameters(4);
     omegaY = source.Parameters(5);
     omegaZ = source.Parameters(6);
     ax = source.Parameters(7);
     ay = source.Parameters(8);
     az = source.Parameters(9);

e1 = -source.Parameters(5)*pi/180;
e2 = -source.Parameters(6)*pi/180;
e3 = -source.Parameters(7)*pi/180;

ba = source.Parameters(8);
ca = source.Parameters(9);

cx = source.Parameters(1);
cy = source.Parameters(2);
cz = source.Parameters(3);

[x,y,z] = ellipsoid(0,0,0,ax,ay,az,20);



Rx = [1 0 0;0 cosd(omegaX) sind(omegaX);0 -sind(omegaX) cosd(omegaX)];
Ry = [cosd(omegaY) 0 -sind(omegaY);0 1 0;sind(omegaY) 0 cosd(omegaY)];
Rz = [cosd(omegaZ) sind(omegaZ) 0;-sind(omegaZ) cosd(omegaZ) 0;0 0 1];
R = Rz*Ry*Rx;


for i=1:size(x,1)
    for j=1:size(x,2)
        xyz = [x(i,j); y(i,j); z(i,j)];
        XYZ = (R*xyz);
%         x(i,j) = XYZ(2);
%         y(i,j) = XYZ(3);
%         z(i,j) = XYZ(1);
        x(i,j) = XYZ(1);
        y(i,j) = XYZ(2);
        z(i,j) = XYZ(3);
    end
end


X = x+X0;
Y = y+Y0;
Z = z+depth;