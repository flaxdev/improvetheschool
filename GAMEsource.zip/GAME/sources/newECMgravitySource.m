function S = newECMgravitySource()

S = newSource();

S.Type = 'ECMgravity';
S.NParameters = 12; 
S.ParameterNames = {'E','N','U','omegaX�','omegaY�','omegaZ�','ax(m)','ay(m)','az(m)','P(Pa)','rho(kg/m3)',...
         'DM(kg)'};
S.Parameters = [0 0 0 0 0 0 0 0 0 1e6 2700 1000];
S.EParameters = [0 0 0 0 0 0 0 0 0 0 0 0];
S.LowBoundaries = [-1e7 -1e7 -10000 0 0 0 0 0 0 0 0 0];
S.UpBoundaries  = [ 1e7  1e7  0  360 360 360 1000  1000  1000 5e7 2900 20000];
S.ActiveParameters = [ 1  1  1  1  1  1  1  1 1 1 1 1];