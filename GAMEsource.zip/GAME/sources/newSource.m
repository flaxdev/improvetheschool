function S = newSource()

S.Type = 'SourceName';
S.NParameters = 1;
S.ParameterNames = {'AAA'};
S.Parameters = [0];
S.ActiveParameters = [1];
S.EParameters = [0];
S.LowBoundaries = [-1];
S.UpBoundaries = [1];
S.IsActive = 1;
