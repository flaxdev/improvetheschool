function e = ess(x,t)

e = exp(-0.5*(x-t)^2)/sqrt(2*pi);