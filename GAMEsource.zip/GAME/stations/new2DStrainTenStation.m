function S = new2DStrainTenStation()

S = newStation();

S.Type = '2DStrainT';
S.Name = '2straint';
S.Coordinates = [0 0 0];
S.NameCoordinates = {'North','East','Up'};
S.NMeasurements = 3;
S.NameMeasurements = {'max-6','min-6','angle'};
S.Measurements = [0 0 0];
S.Errors = [0.001 0.001 0.001];