function U = doGravity(params, Stations, Terrain, Type)


if strcmp(Type,'Okada') 
    U = getOkubo(params, Stations, Terrain);
elseif strcmp(Type,'OkadaDensity') 
    U = getOkubo(params, Stations, Terrain);
elseif strcmp(Type,'MogiDensity') 
    U = getMogiDensityGravity(params, Stations, Terrain);
elseif strcmp(Type,'MogiMass') 
    U = getMogiMassGravity(params, Stations, Terrain);
elseif strcmp(Type,'ECMgravity') 
    U = getECMgravity(params, Stations, Terrain);
end
