function dg = getMogiDensityGravity(params, Stations, Terrain)

% Telford et al., 1990; Turcotte and Schubert, 2002
freeaircoff = -308.6; % microgal/m
G = 6.67e-11; % Nm2/kg2
ms2tomicrogal = 1e8;

u = getMogi(params, Stations, Terrain);

dens = params(5);


dg = (freeaircoff+4*3.1415*G*dens*ms2tomicrogal/3)*u(3);