function dg = getMogiMassGravity(params, Stations, Terrain)

freeaircoff = -308.6; % microgal/m
G = 6.67e-11; % Nm2/kg2
ms2tomicrogal = 1e8;
x=params(1)-Stations(2);
y=params(2)-Stations(1);
d=(Stations(3)-params(3));
r = norm([x,y,d]);


u = getMogi(params, Stations, Terrain);

dM = params(5);  

dg = G*dM*d*ms2tomicrogal/(r^3) + freeaircoff*u(3); 
