function U = getECMgravity(params, Stations, Terrain)

nu = Terrain.Poisson;
mu = Terrain.rmu;

lambda = 2*mu*nu/(1-2*nu);

gamma = -0.3086e-5;

     X0 = params(1);
     Y0 = params(2);
     depth = Stations(3)-params(3);
     omegaX = params(4);
     omegaY = params(5);
     omegaZ = params(6);
     ax = params(7);
     ay = params(8);
     az = params(9);
     p = params(10);
     rho = params(11);
     DM = params(12);
     
     X = Stations(2);
     Y = Stations(1);
     
     if depth<=0
         disp('NEGATIVE DEPTH: fixed at 0!');
         depth = 0.01;
     end

dg=pECMgravity(X,Y,X0,Y0,depth,omegaX,omegaY,omegaZ,ax,ay,az,p,...
    mu,lambda,rho,DM,gamma);


	U=dg*1e8;
