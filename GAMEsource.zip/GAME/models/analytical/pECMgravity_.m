function [dg,dgDV,dgdVc,dgekk,dgSM,dgFA,dgDM,ue,un,uv,dV,DV]=...
    pECMgravity(X,Y,X0,Y0,depth,omegaX,omegaY,omegaZ,ax,ay,az,p,...
    mu,lambda,rho,DM,gamma)
% pECMgravity
% calculates surface gravity changes and surface displacements caused by a 
% point ECM in a uniform elastic half-space.
% 
% pECM: point Ellipsoidal Cavity Model
% PTD: Point Tensile Dislocation
% EFCS: Earth-Fixed Coordinate System
%
% INPUTS
% X and Y [m]:
% Horizontal coordinates of calculation points in EFCS (East, North, Up). 
% X and Y must have the same number of elements.
%
% X0, Y0 and depth [m]:
% Horizontal coordinates and depth of the point ECM. The depth must be a 
% positive value. 
%
% omegaX, omegaY and omegaZ [degree]:
% Clockwise rotation angles about the X, Y and Z axes, respectively, that 
% specify the orientation of the ellipsoid in space.
%
% ax, ay and az [m]:
% Semi-axes of the ellipsoid along the X, Y and Z axes, respectively, 
% before applying the rotations.
%
% p [Pa]:
% Pressure on the cavity walls. 
% 
% mu and lambda [Pa]:
% Lame constants.
% 
% rho [kg/m^3]:
% The host rock density.
% 
% DM [kg]:
% The net mass of intruded fluids.
% 
% gamma [1/s^2]:
% The free-air gradient. gamma must be a negative number. 
% The theoretical value for gamma is approximately -0.3086e-5 1/s^2.
% 
%
% OUTPUTS
% dg [m/s^2]:
% Total surface gravity change.
% 
% dgDV [m/s^2]:
% Surface gravity changes due to interface cavity (potency DV).
% 
% dgdVc [m/s^2]:
% Surface gravity changes due to chamber volume change (dV).
% 
% dgekk [m/s^2]:
% Surface gravity changes due to hpst rock dilatation.
% Note that dgekk is different from dgMD in pCDMgravity function! 
% 
% dgSM [m/s^2]: 
% Surface gravity changes due to displaced surface mass (Bouguer plate).
% 
% dgFA [m/s^2]:
% Surface gravity changes due to vertical displacement of gravimeter (free 
% air effect).
% 
% dgDM [m/s^2]:
% Surface gravity changes due to intruded fluid mass.
% 
% Note: 1 microGal = 1e-8 m/s^2!
% 
% ue, un and uv [m]:
% Surface displacement components in EFCS.
% 
% dV [m^3]:
% The source volume change (dVc).
% 
% DV [m^3]:
% The total source potency (DV).
%
%
% Example-1: Compare gravity change contributions for massless point 
% ellipsoidal cavities of various aspect ratio:
% 
% [x,y] = meshgrid(0:10:6000,0);
% x0 = 0; y0 = 0; depth = 2300; omegaX = 0; omegaY = 0; omegaZ = 0;
% rho = 2600; DM = 0; gamma = -0.3086e-5; mu = 1e9; lambda = 1e9; p = 1e6;
% ax1 = 0.75e3; ay1 = 0.75e3; az1 = 0.75e3; % sphere
% ax2 = 0.4e3; ay2 = 0.4e3; az2 = 0.75e3; % prolate
% [dg1,~,dgdVc1,dgekk1,dgSM1,dgFA1,~,~,~,~,dV1,DV1] = pECMgravity(x,y,...
%     x0,y0,depth,omegaX,omegaY,omegaZ,ax1,ay1,az1,p,mu,lambda,...
%     rho,DM,gamma);
% [dg2,~,dgdVc2,dgekk2,dgSM2,dgFA2,~,~,~,~,dV2,DV2] = pECMgravity(x,y,...
%     x0,y0,depth,omegaX,omegaY,omegaZ,ax2,ay2,az2,p,mu,lambda,...
%     rho,DM,gamma);
% figure
% subplot(121)
% plot(x/depth,dg1/max(dgSM1),'r','LineWidth',2)
% hold on
% title('Spherical')
% xlabel('x/depth')
% ylabel('Gravity changes / max(\Delta{g}_{SM})')
% plot(x/depth,dgdVc1/max(dgSM1),'g')
% plot(x/depth,dgekk1/max(dgSM1),'b')
% plot(x/depth,dgSM1/max(dgSM1),'k')
% plot(x/depth,dgFA1/max(dgSM1),'k--')
% plot(x/depth,(dgdVc1+dgekk1+dgSM1)/max(dgSM1),'m')
% set(gca,'XLim',[0 max(x)/depth])
% legend('\delta{g}','\Delta{g}_{\delta{V}_c}',...
%     '\Delta{g}_{\epsilon_{kk}}','\Delta{g}_{SM}','\Delta{g}_{FA}',...
%     ['\Delta{g}_{\delta{V}_c}+\Delta{g}_{\epsilon_{kk}}+',...
%     '\Delta{g}_{SM}'],'Location','southeast')
% subplot(122)
% plot(x/depth,dg2/max(dgSM2),'r','LineWidth',2)
% hold on
% title('Prolate')
% xlabel('x/depth')
% ylabel('Gravity changes / max(\Delta{g}_{SM})')
% plot(x/depth,dgdVc2/max(dgSM2),'g')
% plot(x/depth,dgekk2/max(dgSM2),'b')
% plot(x/depth,dgSM2/max(dgSM2),'k')
% plot(x/depth,dgFA2/max(dgSM2),'k--')
% plot(x/depth,(dgdVc2+dgekk2+dgSM2)/max(dgSM2),'m')
% set(gca,'XLim',[0 max(x)/depth])
% legend('\delta{g}','\Delta{g}_{\delta{V}_c}',...
%     '\Delta{g}_{\epsilon_{kk}}','\Delta{g}_{SM}','\Delta{g}_{FA}',...
%     ['\Delta{g}_{\delta{V}_c}+\Delta{g}_{\epsilon_{kk}}+',...
%     '\Delta{g}_{SM}'],'Location','southeast')
% set(gcf,'Position',get(0,'ScreenSize'))
% 
% Example-2: Calculate gravity changes, radial and vertical displacements 
% for the point source in Figure 3 in Nikkhoo and Rivalta (2022)
% 
% [x,y] = meshgrid(0:10:1e4,0);
% x0 = 0; y0 = 0; depth = 5e3; omegaX = 0; omegaY = 0; omegaZ = 0;
% rho = 2600; DM = 0; gamma = -0.3086e-5; mu = 1e9; lambda = 1e9; p = 1e6;
% ax = 0.4*1.842e3; ay = 0.4*1.842e3; az = 1.842e3;
% [dg,~,dgdVc,dgekk,dgSM,dgFA,~,ue,~,uv,dV,DV] = pECMgravity(x,y,...
%     x0,y0,depth,omegaX,omegaY,omegaZ,ax,ay,az,p,mu,lambda,...
%     rho,DM,gamma);
% figure
% subplot(211)
% plot(x/depth,uv./max(uv),'k')
% xlabel('Normalized distance (r/depth)')
% ylabel('Normalized displacements')
% hold on
% plot(x/depth,ue./max(uv),'k')
% set(gca,'YLim',[0 1.2])
% subplot(212)
% plot(x/depth,(dg-dgFA)./max(dgSM),'r')
% xlabel('Normalized distance (r/depth)')
% ylabel('Normalized Gravity changes')
% hold on
% plot(x/depth,dgdVc/max(dgSM),'g')
% plot(x/depth,dgekk/max(dgSM),'b')
% plot(x/depth,dgSM/max(dgSM),'k')
% set(gca,'YLim',[-2.2 1.6])
% legend('\Delta{g}','\Delta{g}_{\delta{V}_c}',...
%     '\Delta{g}_{\epsilon_{kk}}','\Delta{g}_{SM}','Location','southeast')
% ScSz = get(0,'ScreenSize');
% set(gcf,'Position',[1 1 floor(ScSz(3)/3)-10 floor(ScSz(4))])

% Reference journal articles:
% 1)
% Nikkhoo, M., Rivalta, E. (2022):
% Analytical solutions for gravity changes caused by triaxial volumetric 
% sources. Geophysical Research Letters, doi: 10.1029/2021GL095442
% 
% 2)
% Nikkhoo, M., Walter, T. R., Lundgren, P. R., Prats-Iraola, P. (2017):
% Compound dislocation models (CDMs) for volcano deformation analyses.
% Geophysical Journal International, doi: 10.1093/gji/ggw427
% 
% 3)
% Okubo, S. (1991). Potential and gravity changes raised by point 
% dislocations. Geophysical journal international, 
% doi: 10.1111/j.1365-246X.1991.tb00797.x
% 
% 4)
% Eshelby, J. D. (1957): The determination of the elastic field of an 
% ellipsoidal inclusion, and related problems. Proceedings of the royal 
% society of London. Series A. Mathematical and physical sciences.

% Copyright (c) 2022 Mehdi Nikkhoo
%
% Permission is hereby granted, free of charge, to any person obtaining a
% copy of this software and associated documentation files
% (the "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to permit
% persons to whom the Software is furnished to do so, subject to the
% following conditions:
%
% The above copyright notice and this permission notice shall be included
% in all copies or substantial portions of the Software.
%
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
% OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
% MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
% NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
% DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
% OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
% USE OR OTHER DEALINGS IN THE SOFTWARE.

% I appreciate any comments or bug reports.

% Mehdi Nikkhoo
% Created: 2020 Sep 12
% Last modified: 2022 Apr 7
%
% Section 2.1, Physics of Earthquakes and Volcanoes
% Department 2, Geophysics
% Helmholtz Centre Potsdam
% German Research Centre for Geosciences (GFZ)
%
% email:
% mehdi.nikkhoo@gfz-potsdam.de
% mehdi.nikkhoo@gmail.com
%
% website:
% http://www.volcanodeformation.com


if gamma>0
    error('Input error: gamma must be a negetive number!')
end

if depth<=0
    error('Input error: depth must be a positive number!')
end

X = X(:);
Y = Y(:);

nu = lambda/(lambda+mu)/2; % Poisson's ratio
K = lambda+2*mu/3; % Bulk modulus

r0 = 1e-12; % Threshold for stable shape tensor calculation
ax(ax<r0) = r0;
ay(ay<r0) = r0;
az(az<r0) = r0;
[ai,Ind] = sort([ax ay az],'descend');

S = ShapeTensorECM(ai(1),ai(2),ai(3),nu);
Sm = [S(1)-1 S(2) S(3);S(4) S(5)-1 S(6);S(7) S(8) S(9)-1]; % Shape tensor

eT = -inv(Sm)*p*ones(3,1)/3/K; % Transformation strain
V = 4/3*pi*ax*ay*az; % Ellipsoid volume

% calculate volume change
dV = (sum(eT)-p/K)*V;
% calculate total potency
DV = dV+p*V/K;

% calculate individual potencies of the equivalent point CDM
tmp = zeros(3,1);
tmp(Ind) = V*eT;
DVx = tmp(1);
DVy = tmp(2);
DVz = tmp(3);

[dg,dgDV,dgMD,dgSM,dgFA,dgDM,ue,un,uv] = pCDMgravity(X,Y,X0,Y0,depth,...
    omegaX,omegaY,omegaZ,DVx,DVy,DVz,rho,DM,gamma,nu);

dgdVc = dgDV*dV/DV;
dgekk = dgMD+dgDV*(DV-dV)/DV;


function [dg,dgDV,dgMD,dgSM,dgFA,dgDM,ue,un,uv]=pCDMgravity(X,Y,X0,Y0,...
    depth,omegaX,omegaY,omegaZ,DVx,DVy,DVz,rho,DM,gamma,nu)
% For inputs and outputs see help in pCDMgravity.m!

G = 6.67408e-11; % Universal gravitational constant [m^3/kg/s^2]
rhoG = rho*G;

X = X(:);
Y = Y(:);

Rx = [1 0 0;0 cosd(omegaX) sind(omegaX);0 -sind(omegaX) cosd(omegaX)];
Ry = [cosd(omegaY) 0 -sind(omegaY);0 1 0;sind(omegaY) 0 cosd(omegaY)];
Rz = [cosd(omegaZ) sind(omegaZ) 0;-sind(omegaZ) cosd(omegaZ) 0;0 0 1];
R = Rz*Ry*Rx;

Vstrike1 = [-R(2,1),R(1,1),0];
Vstrike1 = Vstrike1/norm(Vstrike1);
strike1 = atan2(Vstrike1(1),Vstrike1(2))*180/pi;
if isnan(strike1)
    strike1 = 0;
end
dip1 = acosd(R(3,1));

Vstrike2 = [-R(2,2),R(1,2),0];
Vstrike2 = Vstrike2/norm(Vstrike2);
strike2 = atan2(Vstrike2(1),Vstrike2(2))*180/pi;
if isnan(strike2)
    strike2 = 0;
end
dip2 = acosd(R(3,2));

Vstrike3 = [-R(2,3),R(1,3),0];
Vstrike3 = Vstrike3/norm(Vstrike3);
strike3 = atan2(Vstrike3(1),Vstrike3(2))*180/pi;
if isnan(strike3)
    strike3 = 0;
end
dip3 = acosd(R(3,3));

% Calculate contribution of the first PTD
if DVx~=0
    [ue1,un1,uv1,dgA1,dgMD1] = PTD_disp_grav_Surf(X,Y,X0,Y0,depth,...
        strike1,dip1,DVx,rhoG,nu);
else
    ue1 = zeros(size(X));
    un1 = zeros(size(X));
    uv1 = zeros(size(X));
    dgA1 = zeros(size(X));
    dgMD1 = zeros(size(X));
end

% Calculate contribution of the second PTD
if DVy~=0
    [ue2,un2,uv2,dgA2,dgMD2] = PTD_disp_grav_Surf(X,Y,X0,Y0,depth,...
        strike2,dip2,DVy,rhoG,nu);
else
    ue2 = zeros(size(X));
    un2 = zeros(size(X));
    uv2 = zeros(size(X));
    dgA2 = zeros(size(X));
    dgMD2 = zeros(size(X));
end

% Calculate contribution of the third PTD
if DVz~=0
    [ue3,un3,uv3,dgA3,dgMD3] = PTD_disp_grav_Surf(X,Y,X0,Y0,depth,...
        strike3,dip3,DVz,rhoG,nu);
else
    ue3 = zeros(size(X));
    un3 = zeros(size(X));
    uv3 = zeros(size(X));
    dgA3 = zeros(size(X));
    dgMD3 = zeros(size(X));
end

ue = ue1+ue2+ue3;
un = un1+un2+un3;
uv = uv1+uv2+uv3;

dgFA = gamma*uv; % Free-air effect

% using Newton's law for a point mass
dgDV = -rhoG*(DVx+DVy+DVz)*depth./((X-X0).^2+(Y-Y0).^2+depth.^2).^1.5;
dgDM = G*DM*depth./((X-X0).^2+(Y-Y0).^2+depth.^2).^1.5;

dgA = dgA1+dgA2+dgA3; % dgA=dgMD+dgSM!
dgMD = dgMD1+dgMD2+dgMD3;
dgSM = dgA-dgMD;
dg = dgFA+dgDV+dgDM+dgA;

function [ue,un,uv,dgA,dgMD]=PTD_disp_grav_Surf(X,Y,X0,Y0,depth,strike,...
    dip,DV,rhoG,nu)
% PTD_disp_grav_Surf calculates surface displacements and gravity changes 
% associated with a point tensile dislocation (PTD) in a uniform elastic 
% half-space (Okada 1985 and Okubo 1991).

% The reference coordinate system is EFCS (East, North, Up).

x = X(:)-X0;
y = Y(:)-Y0;

beta = strike-90; % due to Okada (1985) convention!
Rz = [cosd(beta) -sind(beta);sind(beta) cosd(beta)];
r_betaC = Rz*[x y]'; % transforming horizontal coordinates
x = r_betaC(1,:)';
y = r_betaC(2,:)';

d = depth;
r = (x.^2+y.^2+d.^2).^0.5;
q = y*sind(dip)-d*cosd(dip);

I1 = (1-2*nu)*y.*(1./r./(r+d).^2-x.^2.*(3*r+d)./r.^3./(r+d).^3);
I2 = (1-2*nu)*x.*(1./r./(r+d).^2-y.^2.*(3*r+d)./r.^3./(r+d).^3);
I3 = (1-2*nu)*x./r.^3-I2;
I5 = (1-2*nu)*(1./r./(r+d)-x.^2.*(2*r+d)./r.^3./(r+d).^2);

% Note: For a PTD M0 = DV*mu!
ue = DV/2/pi*(3*x.*q.^2./r.^5-I3*sind(dip)^2);
un = DV/2/pi*(3*y.*q.^2./r.^5-I1*sind(dip)^2);
uv = DV/2/pi*(3*d.*q.^2./r.^5-I5*sind(dip)^2);

r_betaD = Rz'*[ue un]'; % transforming horizontal displacements
ue = r_betaD(1,:)';
un = r_betaD(2,:)';


% calculate gravity changes (Okubo 1991)

x = -r_betaC(2,:)'; % due to a different convention for Rz in Okubo (1991)! 
% Note that y = r_betaC(1,:)', but it is not needed below. y contributes to
% the results only through r, which is invariant (independent of coordinate
% system conventions)!

% First: calculations for DV = 1, dip = 0 and dip = 90
dgA11 = 3*rhoG*d*x.^2./r.^5; % normal to x, tensile slip
dgA33 = 3*rhoG*d^3./r.^5; % normal to z, tensile slip
dgA13 = 3*rhoG*x*d^2./r.^5; % normal to z, shear slip along x

dgMD11 = rhoG*(1-2*nu)*(d./r.^3-1./r./(r+d)+x.^2.*(2*r+d)./r.^3./(r+d).^2);
dgMD33 = 0;
dgMD13 = 0;

% Second: calculations for generic DV and dip
dgA = dgCalc(dgA11,dgA33,dgA13,DV,dip);
dgMD = dgCalc(dgMD11,dgMD33,dgMD13,DV,dip);

function dg=dgCalc(dg11,dg33,dg13,DV,dip)
% dgCalc calculates the results for generic dip and potency values
dg = DV*(sind(dip)^2*dg11+sind(2*dip)*dg13+cosd(dip)^2*dg33);



function [S]=ShapeTensorECM(a1,a2,a3,nu)
% ShapeTensorECM
% calculates the Eshelby (1957) shape tensor components.

if all([a1 a2 a3]==0)
    S = zeros(9,1);
    return
end

% Calculate Ik and Iij terms for triaxial, oblate and prolate ellipsoids
if a1>a2 && a2>a3 && a3>0
    % General case: triaxial ellipsoid
    sin_theta = sqrt(1-a3^2/a1^2);
    k = sqrt((a1^2-a2^2)/(a1^2-a3^2));
    
    % % Calculate Legendre's incomplete elliptic integrals of the first and
    % % second kind using MATLAB Symbolic Math Toolbox
    % F =  mfun('EllipticF',sin_theta,k);
    % E =  mfun('EllipticE',sin_theta,k);
    
    % Calculate Legendre's incomplete elliptic integrals of the first and
    % second kind using Carlson (1995) method (see Numerical computation of
    % real or complex elliptic integrals. Carlson, B.C. Numerical 
    % Algorithms (1995) 10: 13. doi:10.1007/BF02198293)
    tol = 1e-16;
    c = 1/sin_theta^2;
    F = RF(c-1,c-k^2,c,tol);
    E = F-k^2/3*RD(c-1,c-k^2,c,tol);
    
    I1 = 4*pi*a1*a2*a3/(a1^2-a2^2)/sqrt(a1^2-a3^2)*(F-E);
    I3 = 4*pi*a1*a2*a3/(a2^2-a3^2)/sqrt(a1^2-a3^2)*...
        (a2*sqrt(a1^2-a3^2)/a1/a3-E);
    I2 = 4*pi-I1-I3;
    
    I12 = (I2-I1)/(a1^2-a2^2);
    I13 = (I3-I1)/(a1^2-a3^2);
    I11 = (4*pi/a1^2-I12-I13)/3;
    
    I23 = (I3-I2)/(a2^2-a3^2);
    I21 = I12;
    I22 = (4*pi/a2^2-I23-I21)/3;
    
    I31 = I13;
    I32 = I23;
    I33 = (4*pi/a3^2-I31-I32)/3;
    
elseif a1==a2 && a2>a3 && a3>0
    % Special case-1: Oblate ellipsoid
    I1 = 2*pi*a1*a2*a3/(a1^2-a3^2)^1.5*(acos(a3/a1)-a3/a1*...
        sqrt(1-a3^2/a1^2));
    I2 = I1;
    I3 = 4*pi-2*I1;
    
    I13 = (I3-I1)/(a1^2-a3^2);
    I11 = pi/a1^2-I13/4;
    I12 = I11;
    
    I23 = I13;
    I22 = pi/a2^2-I23/4;
    I21 = I12;
    
    I31 = I13;
    I32 = I23;
    I33 = (4*pi/a3^2-2*I31)/3;
    
elseif a1>a2 && a2==a3 && a3>0
    % Special case-2: Prolate ellipsoid
    I2 = 2*pi*a1*a2*a3/(a1^2-a3^2)^1.5*(a1/a3*sqrt(a1^2/a3^2-1)-...
        acosh(a1/a3));
    I3 = I2;
    I1 = 4*pi-2*I2;
    
    I12 = (I2-I1)/(a1^2-a2^2);
    I13 = I12;
    I11 = (4*pi/a1^2-2*I12)/3;
    
    I21 = I12;
    I22 = pi/a2^2-I21/4;
    I23 = I22;
    
    I32 = I23;
    I31 = I13;
    I33 = (4*pi/a3^2-I31-I32)/3;
end

% Calculate the shape-tensor components
if a1==a2 && a2==a3
    % Special case-3: Sphere
    S1111 = (7-5*nu)/15/(1-nu);
    S1122 = (5*nu-1)/15/(1-nu);
    S1133 = (5*nu-1)/15/(1-nu);
    S2211 = (5*nu-1)/15/(1-nu);
    S2222 = (7-5*nu)/15/(1-nu);
    S2233 = (5*nu-1)/15/(1-nu);
    S3311 = (5*nu-1)/15/(1-nu);
    S3322 = (5*nu-1)/15/(1-nu);
    S3333 = (7-5*nu)/15/(1-nu);
else
    % General triaxial, oblate and prolate ellipsoids
    S1111 = 3/8/pi/(1-nu)*a1^2*I11+(1-2*nu)/8/pi/(1-nu)*I1;
    S1122 = 1/8/pi/(1-nu)*a2^2*I12-(1-2*nu)/8/pi/(1-nu)*I1;
    S1133 = 1/8/pi/(1-nu)*a3^2*I13-(1-2*nu)/8/pi/(1-nu)*I1;
    S2211 = 1/8/pi/(1-nu)*a1^2*I21-(1-2*nu)/8/pi/(1-nu)*I2;
    S2222 = 3/8/pi/(1-nu)*a2^2*I22+(1-2*nu)/8/pi/(1-nu)*I2;
    S2233 = 1/8/pi/(1-nu)*a3^2*I23-(1-2*nu)/8/pi/(1-nu)*I2;
    S3311 = 1/8/pi/(1-nu)*a1^2*I31-(1-2*nu)/8/pi/(1-nu)*I3;
    S3322 = 1/8/pi/(1-nu)*a2^2*I32-(1-2*nu)/8/pi/(1-nu)*I3;
    S3333 = 3/8/pi/(1-nu)*a3^2*I33+(1-2*nu)/8/pi/(1-nu)*I3;
end

S = [S1111 S1122 S1133 S2211 S2222 S2233 S3311 S3322 S3333]';

function [rf]=RF(x,y,z,r)
% RF
% calculates the RF term in the Carlson (1995) method for calculating
% elliptic integrals

% r = 1e-16

if any([x,y,z]<0)
    error('x, y and z values must be positive!')
elseif nnz([x,y,z])<2
    error('At most one of the x, y and z values can be zero!')
end

xm = x;
ym = y;
zm = z;
A0 = (x+y+z)/3;
Q = max([abs(A0-x),abs(A0-y),abs(A0-z)])/(3*r)^(1/6);
n = 0;
Am = A0;
while abs(Am)<=Q/(4^n)
    lambdam = sqrt(xm*ym)+sqrt(xm*zm)+sqrt(ym*zm);
    Am = (Am+lambdam)/4;
    xm = (xm+lambdam)/4;
    ym = (ym+lambdam)/4;
    zm = (zm+lambdam)/4;
    n = n+1;
end
X = (A0-x)/4^n/Am;
Y = (A0-y)/4^n/Am;
Z = -X-Y;
E2 = X*Y-Z^2;
E3 = X*Y*Z;
rf = (1-E2/10+E3/14+E2^2/24-3*E2*E3/44)/sqrt(Am);

function [rd]=RD(x,y,z,r)
% RD
% calculates the RD term in the Carlson (1995) method for calculating
% elliptic integrals

% r = 1e-16

if z==0
    error('z value must be nonzero!')
elseif all([x,y]==0)
    error('At most one of the x and y values can be zero!')
end

xm = x;
ym = y;
zm = z;
A0 = (x+y+3*z)/5;
Q = max([abs(A0-x),abs(A0-y),abs(A0-z)])/(r/4)^(1/6);
n = 0;
Am = A0;
S = 0;
while abs(Am)<=Q/(4^n)
    lambdam = sqrt(xm*ym)+sqrt(xm*zm)+sqrt(ym*zm);
    S = S+(1/4^n)/sqrt(zm)/(zm+lambdam);
    Am = (Am+lambdam)/4;
    xm = (xm+lambdam)/4;
    ym = (ym+lambdam)/4;
    zm = (zm+lambdam)/4;
    n = n+1;
end

X = (A0-x)/4^n/Am;
Y = (A0-y)/4^n/Am;
Z = -(X+Y)/3;
E2 = X*Y-6*Z^2;
E3 = (3*X*Y-8*Z^2)*Z;
E4 = 3*(X*Y-Z^2)*Z^2;
E5 = X*Y*Z^3;
rd = (1-3*E2/14+E3/6+9*E2^2/88-3*E4/22-9*E2*E3/52+3*E5/26)/4^n/Am^1.5+3*S;
